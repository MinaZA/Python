import pygame
#from player import *





pygame.init()
windows = pygame.display.set_mode((1386,490))
background = pygame.image.load('fond.jpg')
background = pygame.transform.scale(background, (1386,490))
frame_per_sec = pygame.time.Clock()
#p1 = Player()
#p2 = Player()

while True:
    windows.blit(background, (0,0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT :
            pygame.quit()
    pygame.display.update()
