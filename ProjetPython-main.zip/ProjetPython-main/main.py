from game import GAME

GAME()

GAME.Combat()