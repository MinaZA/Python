class Phrase :
    
    def __init__(self, tour):
        self.tour = tour
        if tour=="1" :
            self.phrase = "Ta mere est tellement grosse..."
        if tour=="2" :
            self.phrase = "Le matin ideale pour toi ? Cafe, douche et ..."
        if tour=="3" :
            self.phrase = ""
        if tour=="4" :
            self.phrase = ""
        if tour=="5" :
            self.phrase = ""
        if tour=="6" :
            self.phrase = ""

        
        
        