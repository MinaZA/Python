class Joueur : 

    def __init__(self, name) :
        self.pv = 20
        self.name = name


